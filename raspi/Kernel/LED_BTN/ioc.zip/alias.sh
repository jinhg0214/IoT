alias sd="sudo rmmod ioc"
alias sc="sudo insmod ioc.ko"
